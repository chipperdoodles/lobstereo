Copyright Martin Knobel (chipperdoodles) 2019-2020

This documentation describes Open Hardware and is licensed under the CERN OHL v. 1.2.

You may redistribute and modify this documentation under the terms of theCERN OHL v.1.2. (http://ohwr.org/cernohl). This documentation is distributed WITHOUT ANY EXPRESS OR IMPLIED WARRANTY, INCLUDING, OF MERCHANTABILITY, SATISFACTORY QUALITY AND FITNESS FOR   APARTICULAR PURPOSE. Please see the CERN OHL v.1.2 for applicable conditions.

The Chlomixer Lobstereo is an audio mixer based on a teensy 3.2 and the teensy audio library. 

It's basically two teensy audio boards in one plus some pots on one board and minus some input/outputs and the SD card. 

It's meant to mix 4 channels of in (2 channels per SGTL5000) and output them to headphone out only.

The pots can be used as volume control for each channel and overall volume.